# Upload this portfolio to GitHub

1. Sign in at https://github.com/adura-byte
2. Select **New repository**.
3. Repository name: `QA-Testing-Portfolio`
4. Description: `Beginner QA portfolio: manual test cases, sample bug reports, and test summaries.`
5. Choose **Public** if you want recruiters to view it (do not upload private/customer data).
6. Create repository.
7. On the repository page, choose **Add file → Upload files**.
8. Upload the files and folders from this portfolio ZIP (or extract it first).
9. Commit message: `Add beginner QA portfolio`.
10. Select **Commit changes**.

Your repository URL will then be:
https://github.com/adura-byte/QA-Testing-Portfolio

Do not claim sample bugs were actually found or reported. Replace practice examples with verified findings as you test.
