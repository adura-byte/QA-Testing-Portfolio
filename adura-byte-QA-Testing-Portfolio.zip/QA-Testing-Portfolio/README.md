# QA Testing Portfolio — adura-byte

Welcome to my QA Testing Portfolio. This repository documents my learning and practical exercises in software quality assurance, with a focus on manual testing, test case design, defect reporting, and clear test documentation.

> **Portfolio status:** Beginner practice portfolio. The test scenarios and defect examples in this repository are learning exercises. They are not claims of defects discovered in a production system unless explicitly stated and verified.

## About me
I am building practical skills in Quality Assurance (QA), including:
- Manual and functional testing
- Test scenario and test case design
- Positive, negative, and boundary testing
- Defect/bug reporting
- Test execution and summary reporting
- Attention to detail and clear communication

## Projects

### 1. Login page testing
A practice exercise covering login validation and common user inputs.

- [Test cases](test-cases/login-test-cases.csv)
- [Sample bug reports](bug-reports/sample-login-bugs.md)
- [Test summary](test-summary/login-test-summary.md)

## How I report defects
Each bug report captures:
- Bug ID and title
- Environment
- Preconditions
- Steps to reproduce
- Expected result
- Actual result
- Severity and priority
- Evidence (when available)

## Tools
- GitHub for version control and portfolio presentation
- Spreadsheet/CSV for test cases
- Postman and browser developer tools as I expand this portfolio

## Contact
GitHub: https://github.com/adura-byte

---
I welcome feedback and opportunities to learn, collaborate, and improve my QA skills.
