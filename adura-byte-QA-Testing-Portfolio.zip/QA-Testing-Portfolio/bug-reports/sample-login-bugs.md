# Sample Login Bug Reports (Practice Examples)

**Important:** These are illustrative practice reports, not verified bugs from a live application. Replace them with evidence-backed findings after testing a real website or app.

## BUG-PRACTICE-001 — Login form accepts an empty password (example only)

- **Environment:** Practice login page; browser/device to be recorded during actual execution
- **Precondition:** Login page is open
- **Steps to reproduce:**
  1. Enter a valid test username.
  2. Leave the password field empty.
  3. Click **Login**.
- **Expected result:** The application blocks submission and displays a password-required validation message.
- **Example actual result:** In this hypothetical example, the form proceeds despite the empty password.
- **Severity:** High (if authentication is actually bypassed); otherwise reassess based on observed behavior.
- **Priority:** To be assigned with the product team.
- **Evidence:** Add a screenshot or screen recording only after reproducing this behavior.
- **Status:** Practice example — not verified.

## BUG-PRACTICE-002 — Password visibility control does not toggle (example only)

- **Environment:** Practice login page; record browser/device during actual execution
- **Precondition:** Login page has a password visibility control
- **Steps to reproduce:**
  1. Enter a password.
  2. Click the visibility control.
  3. Observe the password field.
- **Expected result:** The password switches between masked and visible states.
- **Example actual result:** In this hypothetical example, clicking the control does not change the field state.
- **Severity:** Low (usability; confirm product/security context).
- **Priority:** To be assigned with the product team.
- **Evidence:** Attach screenshot/video after reproducing.
- **Status:** Practice example — not verified.

## Defect reporting checklist
- Reproduce the issue more than once where safe.
- Record exact environment and test data without exposing real passwords or personal data.
- Include clear steps and expected vs. actual behavior.
- Capture evidence and report through the approved channel.
- Never test authentication bypasses or repeated lockouts on systems without permission.
